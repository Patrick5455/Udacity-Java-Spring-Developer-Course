package com.example.mvc_basics;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class MvcBasicsApplication {

    public static void main(String[] args) {
        SpringApplication.run(MvcBasicsApplication.class, args);
    }

}
