package com.example.springbootthymetestswaplog;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SpringBootThymeTestSwapLogApplication {

	public static void main(String[] args) {
		SpringApplication.run(SpringBootThymeTestSwapLogApplication.class, args);
	}

}
